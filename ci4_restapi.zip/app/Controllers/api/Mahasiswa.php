<?php

namespace App\Controllers\Api;

use App\Models\MahasiswaModel;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;

class Mahasiswa extends ResourceController
{
    private $modelmahasiswa;
    public function __construct()
    {
        helper('form');
        $this->modelmahasiswa = new MahasiswaModel();
    }

    /**
     * Return an array of resource objects, themselves in array format
     *
     * @return mixed
     */
    public function index()
    {
        $data['mahasiswa'] = $this->modelmahasiswa->orderBy('id', 'DESC')->findAll();
        return $this->respond($data);
    }

    /**
     * Return the properties of a resource object
     *
     * @return mixed
     */
    public function show($id = null)
    {
        $data['mahasiswa'] = $this->modelmahasiswa->orderBy('id', 'DESC')->find($id);

        if ($data['mahasiswa']) {
            return $this->respond($data);
        } else {
            return $this->failNotFound('No Mahasiswa found');
        }
    }

    /**
     * Return a new resource object, with default properties
     *
     * @return mixed
     */
    public function new()
    {
        //
    }

    /**
     * Create a new resource object, from "posted" parameters
     *
     * @return mixed
     */
    public function create()
    {
        $resPost = $this->request->getVar();
        // count($resPost) == 4

        $data = [
            'npm'  => $this->request->getVar('npm'),
            'nama' => $this->request->getVar('nama'),
            'email'  => $this->request->getVar('email'),
            'jurusan'  => $this->request->getVar('jurusan'),
        ];

        $rules = $this->modelmahasiswa->validationRules;

        $input = $this->request->getVar();

        if (!$this->validateData($input, $rules)) {


            $response = [
                'status'   => 201,
                // 'error'    =>  validation_list_errors(),
                // gagal karena belum import helper form
                'error'    =>  validation_errors(),
                'messages' => [
                    'success' => 'Mahasiswa Failed Parameter successfully'
                ]
            ];
            return $this->respond($response);
            // return $this->failForbidden('Forbidden a', null);
        } else {

            $this->modelmahasiswa->save($data);

            $response = [
                'status'   => 201,
                'error'    => null,
                'messages' => [
                    'success' => 'Mahasiswa created successfully'
                ]
            ];
            return $this->respondCreated($response);
        }
    }

    /**
     * Return the editable properties of a resource object
     *
     * @return mixed
     */
    public function edit($id = null)
    {
        //
    }

    /**
     * Add or update a model resource, from "posted" properties
     *
     * @return mixed
     */
    public function update($id = null)
    {
        // $id = $this->request->getVar('id');

        $data = $this->modelmahasiswa->where('id', $id)->first();
        if ($data) {

            $rules = $this->modelmahasiswa->validationRules;

            $input = $this->request->getVar();

            $data = [
                'npm'  => $this->request->getVar('npm'),
                'nama' => $this->request->getVar('nama'),
                'email'  => $this->request->getVar('email'),
                'jurusan'  => $this->request->getVar('jurusan'),
            ];

            $this->modelmahasiswa->update($id, $data);

            $response = [
                'status'   => 200,
                'error'    => null,
                'messages' => [
                    'success' => 'Mahasiswa updated successfully'
                ]
            ];
            return $this->respond($response);

            $rules = [
                'npm'     => 'required|alpha_numeric_space|min_length[9]',
                // 'email'        => 'required|valid_email|is_unique[mahasiswa.email]',
                'nama'        => 'required',
                'jurusan'        => 'required',
            ];

            if (!$this->validateData($input, $rules)) {

                $response = [
                    'status'   => 201,
                    // 'error'    =>  validation_list_errors(),
                    // gagal karena belum import helper form
                    'error'    =>  validation_errors(),
                    'messages' => [
                        'success' => 'Mahasiswa Failed Parameter successfully'
                    ]
                ];
                return $this->respond($response);
                // return $this->failForbidden('Forbidden a', null);
            } else {
            }
        } else {
            return $this->failNotFound('No Mahasiswa found');
        }
    }

    /**
     * Delete the designated resource object from the model
     *
     * @return mixed
     */
    public function delete($id = null)
    {
        $data = $this->modelmahasiswa->where('id', $id)->first();
        if ($data) {
            $this->modelmahasiswa->delete($id);
            $response = [
                'status'   => 200,
                'error'    => null,
                'messages' => [
                    'success' => 'Mahasiswa successfully deleted'
                ]
            ];
            return $this->respondDeleted($response);
        } else {
            return $this->failNotFound('No Mahasiswa found');
        }
    }
}
